//
//  AppDelegate.h
//  Localizame Example
//


#import <Cocoa/Cocoa.h>


@interface AppDelegate : NSObject {
   IBOutlet NSTextField *textField;
   IBOutlet NSTextField *label;
   IBOutlet NSTextField *textlogin;
   IBOutlet NSTextField *labelogin;
   IBOutlet NSTextField *textpassword;
   IBOutlet NSTextField *labelpassword;
   IBOutlet NSTextField *textmensaje;
   IBOutlet NSTextField *labelmensaje;
   IBOutlet NSTextField *textdestino;
   IBOutlet NSTextField *labeldestino;
	
	IBOutlet NSTextField *phone;
	IBOutlet NSTextField *lphone;
	NSString * USER;
	NSString * PASSWORD;
   
}

- (IBAction) clickButton: (id)sender;
- (IBAction)clickButtonAuthorize:(id)sender;
- (IBAction)clickButtonUnauthorize:(id)sender;


@end
