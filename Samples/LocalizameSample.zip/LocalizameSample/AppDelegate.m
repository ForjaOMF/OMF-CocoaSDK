//
//  AppDelegate.m
//  Localizame Example
//

#import "AppDelegate.h"
#import "Localizame.h"

@implementation AppDelegate

 - (void)clickButton:(id)sender;
 {
 
    Localizame * APILocalizame;
	APILocalizame = [Localizame alloc];
	NSString * publicar = [NSString stringWithFormat:@"Error"];
	 if ([APILocalizame Login:[textlogin stringValue] password:[textpassword stringValue]]) {
		 if ([APILocalizame Authorize:[textlogin stringValue]]) {
			 publicar = [NSString stringWithFormat:[APILocalizame Locate:[textlogin stringValue]]];
			 [APILocalizame Logout];
		} 
	 }
	 [textField setStringValue: publicar];
	 [APILocalizame dealloc];
	
 }

 - (void)clickButtonAuthorize:(id)sender;
{
	Localizame * APILocalizame;
	APILocalizame = [Localizame	alloc];
	NSString * result = [NSString stringWithFormat:@"Error"];
	if ([APILocalizame Login:[textlogin stringValue] password:[textpassword stringValue]]) {
		if ([APILocalizame Authorize:[phone stringValue]]) {
			result = [NSString stringWithFormat:@"Autorizado"];
			[APILocalizame Logout];
		}
	}
	[textField setStringValue: result];
	[APILocalizame dealloc];
	
}
 - (void)clickButtonUnauthorize:(id)sender;
{
	Localizame * APILocalizame;
	APILocalizame = [Localizame	alloc];
	NSString * result = [NSString stringWithFormat:@"Error"];
	if ([APILocalizame Login:[textlogin stringValue] password:[textpassword stringValue]]) {
		if ([APILocalizame Unauthorize:[phone stringValue]]) {
			result = [NSString stringWithFormat:@"Desautorizado"];
			[APILocalizame Logout];
		}
	}
	[textField setStringValue: result];
	[APILocalizame dealloc];
}
 
@end
