//
//  AppDelegate.m
//  SMSSend Example
//

#import "AppDelegate.h"
#import "SMSSender.h"


@implementation AppDelegate

 - (void)clickButton:(id)sender;
 {
 
    SMSSender * SMSopen;
	SMSopen = [SMSSender alloc];
	NSString * publish;
	publish = [NSString stringWithFormat:[SMSopen SendMessage:[textlogin stringValue] password:[textpassword stringValue] destination:[textdestino stringValue] message:[textmensaje stringValue]]];
	[labelresult setStringValue:publish];
	[SMSSender dealloc];
 
 }
 
@end
