//
//  POP3.h
//  SMS Receiver Sample
//
#import <Cocoa/Cocoa.h>
#import "SMSReceiver.h"


@interface POP3 : NSObject {
	SMSReceiver *buzon;
	IBOutlet NSTextField *user;
	IBOutlet NSTextField *password;
	IBOutlet NSTextField *server;
	IBOutlet NSTextField *port;
	IBOutlet NSTableView *table;
	IBOutlet NSTextView *text;
	IBOutlet NSTextField *texto;


	NSMutableArray *array;
	NSTimer *temporizador;
	int Destino;
}
	
	@property (nonatomic, retain) NSTextField *user;
	@property (nonatomic, retain) NSTextField *password;
	@property (nonatomic, retain) NSTextField *server;
	@property (nonatomic, retain) NSTextField *port;
	@property (nonatomic, retain) NSTableView *table;
	@property (nonatomic, retain) NSTextView *text;
@property (nonatomic, retain) NSTextField *texto;

	


- (IBAction) clickButton: (id) sender;
- (IBAction)tableViewSelected:(id)sender;

@end
