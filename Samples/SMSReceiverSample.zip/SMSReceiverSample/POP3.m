//
//  POP3.m
//  SMS Receiver Sample
//


#import "POP3.h"


@implementation POP3

@synthesize user, password, server, port, table,text,texto;

- (IBAction) clickButton: (id) sender
{
	NSAutoreleasePool *pool;
	pool = [[NSAutoreleasePool alloc] init];
	array = [NSMutableArray new];
	buzon = [[SMSReceiver alloc] init];
	[buzon setDelegate:self];
	NSLog(@"Servidor: %@ Puerto: %@ Usuario: %@ Password: %@",[server stringValue], [port stringValue], [user stringValue], [password stringValue]);
	[buzon setup:[server stringValue] port:[port intValue] user:[user stringValue] password:[password stringValue]];
	[buzon start];
	
	
}

- (void) receptionFinished: (NSMutableArray*) messages_list {
	array = messages_list;

	NSLog(@"Metodo lanzado automaticamente");
	SMS_Message *mensaje = [[SMS_Message alloc] init];
	uint cuantos = [array count];
	if (cuantos == 0) {
		NSLog(@"Lista de mensajes vacia: No hay mensajes SMS en el servidor");
	} else {
		NSLog(@"Recibidos %d mensajes",cuantos);
		while (cuantos > 0) {
			mensaje = [messages_list objectAtIndex:(cuantos-1)];
			NSLog(@"Imprimo el %d de la lista: %@ %@", cuantos,mensaje.phone, mensaje.text);
			cuantos = cuantos - 1;
		}
    }
	array = messages_list;
	[table reloadData];
}

- (int)numberOfRowsInTableView:(NSTableView *)aTableView
{
    return [array count];
}
- (id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex
{
	SMS_Message *message = [array objectAtIndex:rowIndex];
    NSParameterAssert(rowIndex >= 0 && rowIndex < [array count]);
    return message.phone;
}

- (IBAction)tableViewSelected:(id)sender
{
    Destino = [sender selectedRow];
	NSLog(@"%d",Destino);
	SMS_Message *sms_selected = [array objectAtIndex:Destino];
	[texto setStringValue:sms_selected.text];
}

@end


