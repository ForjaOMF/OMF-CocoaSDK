//
//  AppDelegate.m
//  AutoWP Example
//  

#import "AppDelegate.h"
#import "AutoWP.h"


@implementation AppDelegate

 - (void)clickButton:(id)sender;
 {
 
    AutoWP * WPopen;
	WPopen = [AutoWP alloc];
	NSString * result;
	result = [NSString stringWithFormat:[WPopen SendAutoWP:[textlogin stringValue] password:[textpassword stringValue] url: [textdestino stringValue] text: [textmensaje stringValue]]];
	[textField setStringValue:result];
	[WPopen dealloc];

 }
 
@end
