//
//  AppDelegate.h
//  AutoWP Example
//

#import <Cocoa/Cocoa.h>


@interface AppDelegate : NSObject {
   IBOutlet NSTextField *textField;
   IBOutlet NSTextField *label;
   IBOutlet NSTextField *textlogin;
   IBOutlet NSTextField *labelogin;
   IBOutlet NSTextField *textpassword;
   IBOutlet NSTextField *labelpassword;
   IBOutlet NSTextField *textmensaje;
   IBOutlet NSTextField *labelmensaje;
   IBOutlet NSTextField *textdestino;
   IBOutlet NSTextField *labeldestino;
   
}

- (IBAction) clickButton: (id)sender;

@end
