//
//  AppDelegate.m
//  SampleSMS20
//


#import "AppDelegate.h"


@implementation AppDelegate

@synthesize user, password, table, alias, conversacion, mensaje, estado;

- (IBAction) clickLogin: (id) sender {
	array = [NSMutableArray new];
	API = [[[SMS20 alloc] init] retain];
	API_AUX = [[SMS20Helper alloc] retain];
	sessionid = [API Login:[user stringValue] Password:[password stringValue]];
	if (sessionid == nil) {
		[estado setStringValue:@"Error en login"];
	} else {
		[estado setStringValue:@"Login correcto"];
		contactos = [[API Connect:[user stringValue] Nickname:[alias stringValue]] retain];
		if ([contactos count] != 0) {
			id key;
			NSEnumerator * numerator = [contactos keyEnumerator];
			while (key = [numerator nextObject]) {
				SMS20Contact *Contact;
				Contact = [contactos objectForKey:key];
				NSLog(Contact.alias);
				[array addObject:Contact];
			}
		}
		temporizador = [NSTimer scheduledTimerWithTimeInterval:3.0 target:self selector:@selector(backgroundThreadFire:) userInfo:nil repeats:YES];
	}
	[table reloadData];
	Destino = -1;
}


- (IBAction)tableViewSelected:(id)sender
{
    Destino = [sender selectedRow];
	[mensaje setHidden:FALSE];
}

- (int)numberOfRowsInTableView:(NSTableView *)aTableView
{
    return [array count];
}
- (id)tableView:(NSTableView *)aTableView objectValueForTableColumn:(NSTableColumn *)aTableColumn row:(NSInteger)rowIndex
{
	SMS20Contact *contacts = [array objectAtIndex:rowIndex];
    NSParameterAssert(rowIndex >= 0 && rowIndex < [array count]);
    return contacts.alias;
}

- (IBAction) clickEnviarMensaje: (id) sender {
	SMS20Contact *contact = [array objectAtIndex:Destino];
	NSString *mensajeAenviar = [NSString stringWithFormat:@"Yo:\r\n %@\r\n",[mensaje stringValue]];
	[conversacion insertText:mensajeAenviar];
	[API SendMessage:[user stringValue] Destination:[contact userID] Message:[mensaje stringValue]];
	[estado setStringValue:@"Mensaje enviado"];
	[mensaje setStringValue:@""];
}


-(void)backgroundThreadFire:(id)sender {
	NSString * polling = [API Polling];
	NSString *limit = @"<NewMessage>";
	NSRange rango = [polling rangeOfString:limit];
	if (rango.length != 0) {
		NSRange limite;
		NSString *user1, *mensaje1;
		limit = [API_AUX NewMessage:polling];
		limite = [limit rangeOfString:@"wv"];
		mensaje1 = [limit substringToIndex:limite.location];
		user1 = [limit substringFromIndex:limite.location];
		limit = [NSString stringWithFormat:@"%@ dice:\r\n %@\r\n",user1,mensaje1];
		[estado setStringValue:@"Mensaje entrante"];
		[conversacion insertText:limit];
	} else {
		limit = @"<PresenceNotification-Request>";
		[estado setStringValue:@"Notificación de presencia"];
	}	
}

-(void)backgroundThreadTerminate {
	[temporizador invalidate];
	CFRunLoopStop([[NSRunLoop currentRunLoop] getCFRunLoop]);
}


@end
