//
//  AppDelegate.h
//  SampleSMS20
//


#import <Cocoa/Cocoa.h>
#import "SMS20.h"


@interface AppDelegate : NSObject {
	IBOutlet NSTextField *user;
	IBOutlet NSTextField *password;
	IBOutlet NSTextField *alias;
	IBOutlet NSTableView *table;
	IBOutlet NSTextView *conversacion;
	IBOutlet NSTextField *mensaje;
	IBOutlet NSTextField *estado;
	SMS20 *API;
	SMS20Helper *API_AUX;
	NSMutableArray *array;
	NSDictionary *contactos;
	NSTimer *temporizador;
	int Destino;
	NSString *sessionid;
}

@property (nonatomic, retain) NSTextField *user;
@property (nonatomic, retain) NSTextField *password;
@property (nonatomic, retain) NSTextField *alias;
@property (nonatomic, retain) NSTextField *mensaje;
@property (nonatomic, retain) NSTextField *estado;
@property (nonatomic, retain) NSTextView *conversacion;
@property (nonatomic, retain) NSTableView *table;

- (IBAction) clickLogin: (id) sender;
- (IBAction)tableViewSelected:(id)sender;
- (IBAction) clickEnviarMensaje: (id) sender;


@end
