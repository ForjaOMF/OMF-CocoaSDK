//
//  AppDelegate.m
//  Ejemplo MMSSender
//


#import "AppDelegate.h"
#import "MMSSender.h"


@implementation AppDelegate

@synthesize tuser, tpassword, tto, tsubject, tmessage, timagePath, lresult;

- (IBAction) clickButton: (id) sender {
	MMSSender * APIMMS;
	APIMMS = [MMSSender alloc];
	if ([APIMMS Login: [tuser stringValue] Password: [tpassword stringValue]]) {
		[APIMMS InsertImage:[timagePath stringValue] Path: [timagePath stringValue]];
		//[APIMMS InsertAudio:user Path: pass];
		if ([APIMMS SendMessage:[tsubject stringValue] To:[tto stringValue] Text:[tmessage stringValue]])
			[lresult setStringValue:@"Mensaje Enviado"];
		[APIMMS Logout];
	}
	else
		[lresult setStringValue:@"Error en el envío"];
	[APIMMS dealloc];

		
	
}

@end
