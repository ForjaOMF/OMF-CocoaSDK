//
//  AppDelegate.h
//  Ejemplo MMSSender
//


#import <Cocoa/Cocoa.h>


@interface AppDelegate : NSObject {
	IBOutlet NSTextField * tuser;
	IBOutlet NSTextField * tpassword;
	IBOutlet NSTextField * tto;
	IBOutlet NSTextField * tmessage;
	IBOutlet NSTextField * tsubject;
	IBOutlet NSTextField * timagePath;
	IBOutlet NSTextField * lresult;

}

@property (nonatomic, retain) NSTextField * tuser;
@property (nonatomic, retain) NSTextField * tpassword;
@property (nonatomic, retain) NSTextField * tto;
@property (nonatomic, retain) NSTextField * tsubject;
@property (nonatomic, retain) NSTextField * tmessage;
@property (nonatomic, retain) NSTextField * timagePath;
@property (nonatomic, retain) NSTextField * lresult;

- (IBAction) clickButton: (id) sender;

@end
