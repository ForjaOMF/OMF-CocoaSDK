//
//  AppDelegate.m
//  Copiagende Example
//


#import "AppDelegate.h"
#import "Copiagenda.h"

@implementation AppDelegate

 - (void)clickButton:(id)sender;
{
 
    Copiagenda * APIC;
	APIC = [Copiagenda alloc];
	NSString * publicar;
	NSDictionary * contactos;
	contactos = [APIC RetrieveContacts:[textlogin stringValue] password:[textpassword stringValue]];
	id key;
	NSEnumerator * numerator = [contactos keyEnumerator];
	NSString *cliente = [NSString stringWithFormat:@" "];
	publicar = [NSString stringWithFormat:@"Lista de Contactos: \r\n"];
	while (key = [numerator nextObject]) {
		cliente = [NSString stringWithFormat:@"Contacto = %@\r\n Contenido = %@\r\n\r\n",[key description],[[contactos objectForKey:key] description]];
		publicar = [publicar stringByAppendingString:cliente];
		
	}
	[textField setStringValue:publicar];
	[APIC dealloc];
}

- (IBAction) buscarcontacto: (id)sender {
	Copiagenda * APIC;
	APIC = [Copiagenda alloc];
	NSString * publicar;
	NSDictionary * contactos;
	contactos = [APIC RetrieveContacts:[textlogin stringValue] password:[textpassword stringValue]];
	publicar = [NSString stringWithFormat:@"%@",[APIC SearchByName:[textcontact stringValue] contacts:contactos]];
	[textField setStringValue:publicar];
	[APIC dealloc];
}
 
@end
